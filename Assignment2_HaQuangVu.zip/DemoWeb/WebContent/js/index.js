function swap(file) {
	document.logo.src=file;
}